
if(window.location.hash){
 const token = new URLSearchParams(window.location.hash.substring(1)).get('access_token');
 if(token){
  fetch('https://discord.com/api/users/@me', {
   headers: { Authorization: 'Bearer ' + token }
  })
  .then(r=>r.json())
  .then(user=>{
    const el=document.getElementById('user');
    if(el) el.innerText='Connecté : '+user.username+'#'+user.discriminator;
  });
 }
}
