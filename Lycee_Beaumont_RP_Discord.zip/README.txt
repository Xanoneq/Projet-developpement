
INSTALLATION RP – Lycée Beaumont

1. Crée une application Discord
2. Récupère le CLIENT ID
3. Remplace CLIENT_ID_ICI dans index.html
4. Mets ton URL du site dans REDIRECT_URI_ICI
5. Héberge (GitHub Pages recommandé)

Connexion Discord opérationnelle.
